﻿namespace Moto.Controllers.DTO
{
    public class CartItemData
    {
        public Guid ProductId { get; set; }
        public int Count { get; set; }
    }
}
