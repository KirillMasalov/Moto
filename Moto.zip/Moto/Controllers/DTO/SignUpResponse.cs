﻿namespace Moto.Controllers.DTO
{
    public class SignUpResponse
    {
        public int Code { get; set; }
        public string Message { get; set; }
    }
}
