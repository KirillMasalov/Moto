﻿namespace Moto.DB.Models.Products
{
    public static class Category
    {
        public static string Motorcycle = "Motorcycle";
        public static string Quadrocycle = "Quadrocycle";
        public static string Accessory = "Accessory";
    }
}
