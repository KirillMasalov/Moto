﻿using Microsoft.AspNetCore.Identity;

namespace Moto.DB.Models
{
    public class User : IdentityUser
    {
    }
}
